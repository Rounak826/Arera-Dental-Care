import React from "react";
import "./home.css";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
import slideone from "./slideone.jpg";
import slidetwo from "./slidetwo.jpg";
import slidethree from "./slidethree.jpg";
import slidefour from "./slidefour.jpg";
import Image1 from "./Image1.jpg";
import Image2 from "./Image2.jpg";
import Image3 from "./Image3.jpg";
import introimage from "./introimage.jpg";
import teamimage from "./teamimage.svg";
import healthlogo1 from "./healthlogo1.svg";
import healthlogo2 from "./healthlogo2.svg";
import healthlogo3 from "./healthlogo3.svg";
import healthlogo4 from "./healthlogo4.svg";
import achievementlogo1 from "./achievementlogo1.svg";
import achievementlogo2 from "./achievementlogo2.svg";
import achievementlogo3 from "./achievementlogo3.svg";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { Link } from "react-router-dom";
import Popup from "reactjs-popup";
import "reactjs-popup/dist/index.css";
import {
  faYoutube,
  faFacebook,
  faInstagram,
} from "@fortawesome/free-brands-svg-icons";
export const Home = () => {
  return (
    <div className="HomeContainer">
      <div className="Slider">
        <Carousel
          autoPlay={true}
          showThumbs={false}
          infiniteLoop={true}
          interval={10000}
          showArrows={false}
          showStatus={false}
        >
          <div className="Slide">
            <img src={slideone} alt="" className="Image-Button" />
            <h1 >
              Best <span className="Mods">Dental</span> Care For You and Your{" "}
              <span className="Mods">Family</span>
            </h1>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Minima
              totam possimus sed sequi eum dolore neque eaque tempora placeat
              similique sapiente excepturi beatae, perferendis quidem commodi,
              fuga, aperiam libero quos.
            </p>
            <Link to={"/BookAppointment"} class="btn">
              Book Appointment+
            </Link>
          </div>
          <div className="Slide">
            <img src={slidetwo} alt="" />
          </div>
          <div className="Slide">
            <img src={slidethree} alt="" />
          </div>
          <div className="Slide">
            <img src={slidefour} alt="" />
          </div>
        </Carousel>
      </div>
      <div className="Introduction1">
        <div className="Intro-Content">
          <div className="Header-Intro">
            <h1>
              Providing Best Dental Care For You and Your{" "}
              <span className="Mods">Family</span> !
            </h1>
          </div>
          <div className="Content-Intro">
            <p>
              Lorem Ipsum is simply dummy text of the printing and typesetting
              industry. Lorem Ipsum has been the industry's standard dummy text
              ever since the 1500s, when an unknown printer took a galley of
              type and scrambled it to make a type specimen book. It has
              survived not only five centuries, but also the leap into
              electronic typesetting, remaining essentially unchanged. It was
              popularised in the 1960s with the release of Letraset sheets
              containing Lorem Ipsum passages, and more recently with desktop
              publishing software like Aldus PageMaker including versions of
              Lorem Ipsum..............
            </p>
          </div>
        </div>
        <div className="Youtube-Integration">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/dgwJgvdk0K4"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
          ></iframe>
        </div>
      </div>
      <div className="Achievement-div">
        <img src={achievementlogo1} alt="" />
        <h2> <span className="Mods">1,000+</span> Cured Patients </h2>
        <img src={achievementlogo2} alt="" />
        <h2><span className="Mods">1,900+</span> Medical Tests </h2>
        <img src={achievementlogo3} alt="" />
        <h2><span className="Mods">10+</span> Years of Experience</h2>
      </div>

      <div className="Gallery-div">
        <div className="GalleryHeader">
          <h1>Our Gallery</h1>
          <p>
            Our administration and support staff all have exceptional people
            skilled and trained to assist you with all the medical enquiries
          </p>
        </div>
        <div className="GalleryImages">
          <img src={Image1} alt="" />
          <img src={Image2} alt="" />
          <img src={Image3} alt="" />
        </div>
        <div className="GalleryButton">
          <Link to={"/Gallery"} className="Explore-More">
            Explore More!
          </Link>
        </div>
      </div>

      <div className="Introduction-2">
        <div className="Intro-Header">
          <h1>
            We Strive To Provide The{" "}
            <span className="Mods">Best Medical Care </span> !
          </h1>
          <p>
            we will work with you to develop individualized care plans including
            management of chronic diseases .
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Illum labore assumenda odit possimus recusandae at modi, nam dolores voluptatum delectus aliquam iusto repellat asperiores omnis quos. Expedita harum eveniet officiis!
          </p>
        </div>
        <div className="Intro-Image">
          <img src={introimage} alt="" />
        </div>
      </div>

      <div className="Team-div">
        <div className="TeamHeader">
          <h1>OUR TEAM</h1>
        </div>
        <div className="Team-div-Content">
          <div class="card">
            <img src={teamimage} alt="" />
            <h1>John Doe</h1>
            <p class="title">Dentist,MDS</p>
            <p>Arera Dental Clinic</p>
          </div>
          <div class="card">
            <img src={teamimage} alt="" />
            <h1>John Doe</h1>
            <p class="title">Dentist,MDS</p>
            <p>Arera Dental Clinic</p>
          </div>
        </div>
      </div>
      <div className="HealthCard">
        <div className="Card">
          <img src={healthlogo1} alt="" />
          <h3>Medical Advice & Check Ups!</h3>
          <p>Consult any of our doctor by vising anytime!</p>
        </div>
        <div className="Card">
          <img src={healthlogo2} alt="" />
          <h3>Medical Advice & Check Ups!</h3>
          <p>Consult any of our doctor by vising anytime!</p>
        </div>
        <div className="Card">
          <img src={healthlogo3} alt="" />
          <h3>Medical Advice & Check Ups!</h3>
          <p>Consult any of our doctor by vising anytime!</p>
        </div>
        <div className="Card">
          <img src={healthlogo4} alt="" />
          <h3>Medical Advice & Check Ups!</h3>
          <p>Consult any of our doctor by vising anytime!</p>
        </div>
      </div>
      <div class="icon-bar">
        <a
          href="https://www.facebook.com/areradentalclinic/"
          target={"_blank"}
          className="facebook"
          rel="noreferrer"
        >
          <FontAwesomeIcon icon={faFacebook} size="2x" />
        </a>

        <a
          href="https://youtube.com/c/drswapniljain18"
          target={"_blank"}
          className="youtube"
          rel="noreferrer"
        >
          <FontAwesomeIcon icon={faYoutube} size="2x" />
        </a>
        <a
          href="https://instagram.com/arera_dental_care?utm_medium=copy_link"
          target={"_blank"}
          className="instagram"
          rel="noreferrer"
        >
          <FontAwesomeIcon icon={faInstagram} size="2x" />
        </a>
      </div>
      <div className="Feedback">
        <Popup
          trigger={<button className="feedbackBTN">Send Us Feedback</button>}
          position="right center"
        >
          <div>
            <textarea name="Feedback" id="" cols="50" rows="10"></textarea>
            <button type="submit" className="feedbackBTN">
              Send
            </button>
          </div>
        </Popup>
      </div>
    </div>
  );
};
