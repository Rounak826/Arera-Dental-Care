import React from "react";
import "./procedures.css";
import dentalimplantimage from "./dentalimplantimage.jpg";
import bonegraftimage from "./bonegrafimage.png";
import dentistimage from "./dentistimage.png";
import sedation from "./sedation.png";
import teethwhite from "./teethwhite.png";
import dentalcavity from "./dentalcavity.png";
import Proceduresimg from "./Proceduresimg.svg";
import { Link } from "react-router-dom";
export const Procedures = () => {
  return (
    <div className="Procedures">
      <div className="Banner">
        <div className="BannerContent">
          <h1>
            SETS THE STANDARDS FOR OUTSTANDING HIGH{" "}
            <span className="Mods">QUALITY</span> CARE AND{" "}
            <span className="Mods">PATIENT SAFETY</span>.
          </h1>
          <Link to={"/BookAppointment"} className="button1">
            Make Appointment +
          </Link>
          <Link to={"/Aboutus"} className="button2">
            Know more
          </Link>
        </div>
        <img src={Proceduresimg} alt="" />
      </div>
      <div className="ServiceCards">
        <div className="Header">
          <h1>Our Services</h1>
        </div>
        <div className="Row">
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={dentalimplantimage} alt="" />
                <p>Dental Implant</p>
              </div>
              <div className="flip-card-back">
                <h2>Dental Implant Surgery</h2>
                <p>
                  Dental implants are surgically placed in your jawbone, where
                  they serve as the roots of missing teeth.
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={dentalimplantimage} alt="" />
                <p>Dental Implant</p>
              </div>
              <div className="flip-card-back">
                <h2>Dental Implant Surgery</h2>
                <p>
                  Dental implants are surgically placed in your jawbone, where
                  they serve as the roots of missing teeth.
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={bonegraftimage} alt="" />
                <p>Bone Grafting </p>
              </div>
              <div className="flip-card-back">
                <h2>Dental Bone Grafting</h2>
                <p>
                  A dental bone graft is necessary when bone loss has occurred
                  in the jaw.{" "}
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={dentistimage} alt="" />
                <p>Sedation Dentistry</p>
              </div>
              <div className="flip-card-back">
                <h2>Sedation Dentistry</h2>
                <p>
                  {" "}
                  Sedation dentistry uses medication to help patients relax
                  during dental procedures
                </p>
              </div>
            </div>
          </div>
        </div>
        <div className="Row">
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={sedation} alt="" />
                <p>Special Dentistry</p>
              </div>
              <div className="flip-card-back">
                <h2>Special Care Dentistry</h2>
                <p>
                  special care dentistry, is a dental specialty that deals with
                  the oral health problems.
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={dentalimplantimage} alt="" />
                <p>Dental Implant</p>
              </div>
              <div className="flip-card-back">
                <h2>Dental Implant Surgery</h2>
                <p>
                  Dental implants are surgically placed in your jawbone, where
                  they serve as the roots of missing teeth.
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={teethwhite} alt="" />
                <p>Teeth Whitening</p>
              </div>
              <div className="flip-card-back">
                <h2>Teeth Whitening</h2>
                <p>
                  Teeth whitening is one of the most popular cosmetic dentistry
                  treatments offering a quick, non-invasive and affordable way
                  to enhance a smile.
                </p>
              </div>
            </div>
          </div>
          <div className="flip-card">
            <div className="flip-card-inner">
              <div className="flip-card-front">
                <img src={dentalcavity} alt="" />
                <p>Dental Cavity</p>
              </div>
              <div className="flip-card-back">
                <h2>Dental Cavity</h2>
                <p>
                  Cavities are permanently damaged areas in the hard surface of
                  your teeth that develop into tiny openings or holes
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
