import React from "react";
import "./contactus.css";
import contactuslogo from "./contactuslogo.svg";
import addresslogo from "./addresslogo.svg";
import Phonenumber from "./Phonenumberlogo.svg";
import Maillogo from "./Maillogo.svg";
export const ContactUs = () => {
  return (
    <div className="ContactUs">
      <div className="ContactUsForm">
        <div className="ContactUsImage">
          <img src={contactuslogo} alt="" />
          <h1>Arera Dental Clinic</h1>
        </div>
        <div className="form">
          <h1>Contact US</h1>
          <form>
            <label for="firstname">First Name</label>
            <input
              type="text"
              id="fname"
              name="firstname"
              placeholder="Your name.."
            />

            <label for="lastname">Last Name</label>
            <input
              type="text"
              id="lname"
              name="lastname"
              placeholder="Your last name.."
            />

            <label for="subject">Query</label>
            <textarea
              id="subject"
              name="subject"
              placeholder="Write something.."
            ></textarea>

            <input type="submit" value="Submit" />
          </form>
        </div>
      </div>
      <div className="Address">
        <h1>Address</h1>
        <div className="AddressRow">
          <img src={addresslogo} alt="" />
          <p>
            1-d, Bhuta Ho,Opp.panchal Steel Ind., Near Reliance, Mogra Road,
            Andheri (east)
          </p>
        </div>
        <div className="AddressRow">
          <img src={Phonenumber} alt="" />
          <p>+91 90000-00009</p>
        </div>
        <div className="AddressRow">
          <img src={Maillogo} alt="" />
          <p>areradentalclinic@gmail.com</p>
        </div>
      </div>
    </div>
  );
};
